package com.example.a09_04_nhom04_26_04;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.a09_04_nhom04_26_04.model.Student;

import java.util.ArrayList;
import java.util.List;

public class SQLiteStudentHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME="studentDB.db";
    private static final int DATABASE_VERSION = 1;
    public SQLiteStudentHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //tao 1 table co ten la student
        String sql="CREATE TABLE student("+"id INTEGER PRIMARY KEY AUTOINCREMENT," + "name TEXT," + "gender BOOLEAN," + "mark REAL)";
        db.execSQL(sql);
    }
    //add
    public void addStudent(Student s){
        String sql = "INSERT INTO student(name,gender,mark) " +"values(?,?,?) ";
        String[] args = {s.getName(), Boolean.toString(s.isGender()), Double.toString(s.getMark())};
        SQLiteDatabase statement = getWritableDatabase();
        statement.execSQL(sql, args);
    }
    //get all
    public List<Student> getAll(){
        List<Student> list = new ArrayList<>();
        SQLiteDatabase statement = getReadableDatabase();
        Cursor rs = statement.query("student", null, null, null, null, null, null);
        while (rs!=null && rs.moveToNext()){
            int id = rs.getInt(0);
            String name = rs.getString(1);
            boolean gender = rs.getString(2).equals("true");
            double mark = rs.getDouble(3);
            list.add(new Student(id, name, gender, mark));
        }
        return list;
    }
    //get student by ID: SELECT * FROM student WHERE id = ?
    public Student getStudentById(int id){
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        String whereClause = "id = ?";
        String[] whereArgs = {Integer.toString(id)};
        Cursor cursor = sqLiteDatabase.query("student", null, whereClause, whereArgs, null, null, null);
        Student s = null;
        if (cursor != null && cursor.moveToFirst()) {
            int studentId = cursor.getInt(cursor.getColumnIndex("id"));
            String studentName = cursor.getString(cursor.getColumnIndex("name"));
            boolean studentGender = cursor.getString(cursor.getColumnIndex("gender")).equals("true");
            double studentMark=cursor.getDouble(cursor.getColumnIndex("mark"));
            cursor.close();
            s = new Student(studentId,studentName,studentGender,studentMark);
        }
        return s;
    }

    public void update(Student c){
        String sql = "UPDATE student SET name = ?, gender = ?,mark=? WHERE id = ?";
        String[] args = {c.getName(),Boolean.toString(c.isGender()),Double.toString(c.getMark()),Integer.toString(c.getId())};
        SQLiteDatabase stm = getWritableDatabase();
        stm.execSQL(sql,args);
    }

    //delete
    public int delete(int id){
        String whereClause = "id=?";
        String[] whereArgs = {String.valueOf(id)};
        SQLiteDatabase statement = getWritableDatabase();
        return statement.delete("student", whereClause, whereArgs);
    }
    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
