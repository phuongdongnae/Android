package com.example.a09_04_nhom04_26_04;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.a09_04_nhom04_26_04.model.Student;

import java.util.List;

public class MainActivity extends AppCompatActivity{
    private Button btAdd, btAll, btGet, btUpdate, btDelete;
    private EditText txtId, txtName, txtMark;
    private RadioButton male, female;
    private RecyclerView rev;
    private RecyclerViewAdapter adapter;
    private SQLiteStudentHelper sqLite;
    private boolean gender;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        btUpdate.setEnabled(false);
        btDelete.setEnabled(false);
        adapter = new RecyclerViewAdapter();
        rev.setLayoutManager(new LinearLayoutManager(this));
        rev.setAdapter(adapter);
        sqLite = new SQLiteStudentHelper(this);
        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Student s = new Student();
                s.setName(txtName.getText().toString());
                boolean g = false;
                if(male.isChecked()){
                    g = true;
                }
                s.setGender(g);
                s.setMark((Double.parseDouble(txtMark.getText().toString())));
                sqLite.addStudent(s);
            }
        });
        btAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Student> list = sqLite.getAll();
                adapter.setStudents(list);
                rev.setAdapter(adapter);
            }
        });
        btGet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    int id = Integer.parseInt(txtId.getText().toString());
                    Student student = sqLite.getStudentById(id);
                    if(student==null){
                        Toast.makeText(getApplicationContext(), "Khong co", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        txtName.setText(student.getName());
                        txtMark.setText(student.getMark()+"");
                        if(student.isGender()){
                            male.setChecked(true);
                        }
                        else female.setChecked(true);
                    }
                }catch (NumberFormatException e){
                    System.out.println(e);
                }
                btAdd.setEnabled(false);
                btUpdate.setEnabled(true);
                btDelete.setEnabled(true);
            }
        });
        btDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    int id = Integer.parseInt(txtId.getText().toString());
                    sqLite.delete(id);
                }catch (NumberFormatException e){
                    System.out.println(e);
                }
            }
        });
        btUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    int id = Integer.parseInt(txtId.getText().toString());
                    String name = txtName.getText().toString();
                    double mark = Double.parseDouble(txtMark.getText().toString());
                    gender = false;
                    if(male.isChecked()){
                        gender = true;
                    }
                    Student student = new Student(id, name, gender, mark);
                    sqLite.update(student);
                }catch (NumberFormatException e){
                    System.out.println(e);
                }
            }
        });
    }

    private void initView() {
        btAdd = findViewById(R.id.btAdd);
        btAll = findViewById(R.id.btAll);
        btGet = findViewById(R.id.btGet);
        btUpdate = findViewById(R.id.btUpdate);
        btDelete = findViewById(R.id.btDelete);
        txtId = findViewById(R.id.stID);
        txtName = findViewById(R.id.stName);
        txtMark = findViewById(R.id.stMark);
        male = findViewById(R.id.male);
        female = findViewById(R.id.female);
        rev = findViewById(R.id.recyclerView);
    }
}